<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use App\Models\Category;
use App\Models\Post;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // \App\Models\User::factory(10)->create();

        User::create([
            'nama' => 'Fadhila Tsani',
            'email' => 'tsanifadhila@gmail.com',
            'password' =>bcrypt('lalalucu')
        ]);

        Category::create([
            'nama' => 'Travelling',
            'slug' => 'travelling'
        ]);
        Category::create([
            'nama' => 'Personal',
            'slug' => 'personal'
        ]);

        Post::create([
            'title' => 'My First Blog',
            'slug' => 'my-first-blog',
            'excerpt' => 'Lorem ipsum first',
            'body' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Debitis quo atque similique minus ut corrupti illum delectus rerum aperiam! Harum maxime eos nulla ut esse dignissimos officiis fugit incidunt, nam dicta quibusdam nostrum magni atque impedit repellendus eaque consequatur pariatur eligendi consectetur accusantium dolorem amet excepturi, itaque ea! Illo commodi officiis nesciunt similique dignissimos ea odit voluptas dolores mollitia, enim soluta excepturi reiciendis dolore quod voluptate molestias reprehenderit suscipit earum dicta neque explicabo quos labore praesentium. Temporibus architecto veritatis tenetur repudiandae minus placeat nesciunt odit modi? Quae veritatis, sunt autem qui perferendis mollitia reprehenderit quas, iure ea fugiat laudantium quisquam?',
            'category_id' => 3,
            'user_id' => 1
        ]);
        Post::create([
            'title' => 'My Second Blog',
            'slug' => 'my-second-blog',
            'excerpt' => 'Lorem ipsum second',
            'body' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Debitis quo atque similique minus ut corrupti illum delectus rerum aperiam! Harum maxime eos nulla ut esse dignissimos officiis fugit incidunt, nam dicta quibusdam nostrum magni atque impedit repellendus eaque consequatur pariatur eligendi consectetur accusantium dolorem amet excepturi, itaque ea! Illo commodi officiis nesciunt similique dignissimos ea odit voluptas dolores mollitia, enim soluta excepturi reiciendis dolore quod voluptate molestias reprehenderit suscipit earum dicta neque explicabo quos labore praesentium. Temporibus architecto veritatis tenetur repudiandae minus placeat nesciunt odit modi? Quae veritatis, sunt autem qui perferendis mollitia reprehenderit quas, iure ea fugiat laudantium quisquam?',
            'category_id' => 1,
            'user_id' => 1
        ]);
        Post::create([
            'title' => 'My Third Blog',
            'slug' => 'my-third-blog',
            'excerpt' => 'Lorem ipsum third',
            'body' => 'Lorem, ipsum dolor sit amet consectetur adipisicing elit. Debitis quo atque similique minus ut corrupti illum delectus rerum aperiam! Harum maxime eos nulla ut esse dignissimos officiis fugit incidunt, nam dicta quibusdam nostrum magni atque impedit repellendus eaque consequatur pariatur eligendi consectetur accusantium dolorem amet excepturi, itaque ea! Illo commodi officiis nesciunt similique dignissimos ea odit voluptas dolores mollitia, enim soluta excepturi reiciendis dolore quod voluptate molestias reprehenderit suscipit earum dicta neque explicabo quos labore praesentium. Temporibus architecto veritatis tenetur repudiandae minus placeat nesciunt odit modi? Quae veritatis, sunt autem qui perferendis mollitia reprehenderit quas, iure ea fugiat laudantium quisquam?',
            'category_id' => 1,
            'user_id' => 1
        ]);
    }
}
