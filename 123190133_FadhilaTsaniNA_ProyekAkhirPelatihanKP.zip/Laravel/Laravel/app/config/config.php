<?php

define('BASEURL', 'http://localhost/Laravel/Laravel/public');

// DB
define('DB_HOST', 'localhost'); //localhost database
define('DB_USER', 'root'); //username database
define('DB_PASS', ''); // password database
define('DB_NAME', 'my_blog'); //nama database
