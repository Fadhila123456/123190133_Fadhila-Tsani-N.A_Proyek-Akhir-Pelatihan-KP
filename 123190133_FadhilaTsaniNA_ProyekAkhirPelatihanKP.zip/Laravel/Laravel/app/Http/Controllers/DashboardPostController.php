<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Post;

class DashboardPostController extends Controller
{
    public function index()
    {
        return view ('dashboard.posts.index');
    }

    public function create()
    {
        return view ('dashboard.index');
    }

    public function store(Request $request)
    {
        return view ('dashboard.index');
    }
    
    public function show(Post $post)
    {
        return view ('dashboard.index');
    }

    public function edit(Post $post)
    {
        return view ('dashboard.index');
    }

    public function update(Request $request, Post $post)
    {
        return view ('dashboard.index');
    }

    public function destroy(Post $post)
    {
        return view ('dashboard.index');
    }
}