<?php

namespace App\Models;

class Post
{
	private static $blog_posts = [
    [
        "title" => "This My First Posts",
        "slug" => "this-my-first-posts",
        "author" => "Fadhila Tsani",
        "body" => "hay ini blog pertama saya"
    ],
    [
        "title" => "This My Second Posts",
        "slug" => "this-my-second-posts",
        "author" => "Fadhila Tsani",
        "body" => "hay ini blog kedua saya"
    ],
];
	
	public static function all(){
		return collect(self::$blog_posts);
	}

    public static function find($slug){
        $posts = static::all();
        return $posts->firstWhere('slug', $slug);
    }
}