@extends('layouts.main')

@section('container')
		<h2 class="mb-5">{{ $post->title }}</h2>

		<p>Oleh : <a href="#">{{ $post->title }}</a> dalam Kategori <a href="http://localhost/Laravel/Laravel/public/categories/{{ $post->category->slug }}">{{ $post->category->nama }}</a></p>
		
		{{!! $post->body !!}}

	<a href="http://localhost/Laravel/Laravel/public/blog">Kembali ke awal</a>
@endsection