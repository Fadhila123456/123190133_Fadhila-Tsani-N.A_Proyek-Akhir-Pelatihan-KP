@extends('layouts.main')

@section('container')

	<h1>Kategori Posts : {{ $category }}</h1>
	
	@foreach($posts as $post)
		<article class="mb-5 border-bottom pb-3">
			<h2>
				<a href="http://localhost/Laravel/Laravel/public/posts/{{ $post->slug }}" class="text-decoration-none">{{ $post->title }}</a>
			</h2>
			<p>{{ $post->excerpt }}</p>
			<a href="http://localhost/Laravel/Laravel/public/posts/{{ $post->slug }}" class="text-decoration-none">Baca Lebih Banyak</a>
		</article>
	@endforeach

@endsection
