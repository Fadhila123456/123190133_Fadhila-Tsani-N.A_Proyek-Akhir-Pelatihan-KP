@extends('layouts.main')

@section('container')
	<h1>HOME</h1>
@endsection