@extends('layouts.main')

@section('container')

	<h1>Kategori Posts : </h1>
	
	@foreach($categories as $category)
		<ul>
            <li>
                <h2>
                    <a href="http://localhost/Laravel/Laravel/public/categories/{{ $category->slug }}" class="text-decoration-none">{{ $category->title }}</a>
                </h2>
            </li>
		</ul	
	@endforeach

@endsection
