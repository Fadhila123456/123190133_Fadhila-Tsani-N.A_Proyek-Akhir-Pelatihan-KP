

<?php $__env->startSection('container'); ?>
		<h2 class="mb-5"><?php echo e($post->title); ?></h2>

		<p>Oleh : <a href="#"><?php echo e($post->title); ?></a> dalam Kategori <a href="http://localhost/Laravel/Laravel/public/categories/<?php echo e($post->category->slug); ?>"><?php echo e($post->category->nama); ?></a></p>
		
		{<?php echo $post->body; ?>}

	<a href="http://localhost/Laravel/Laravel/public/blog">Kembali ke awal</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/post.blade.php ENDPATH**/ ?>